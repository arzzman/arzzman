/*****************************************************************************
 * Library.h: Multimedia library
 *****************************************************************************
 * Copyright (C) 2008-2016 VideoLAN
 *
 * Authors: Hugo Beauzée-Luyssen <hugo@beauzee.fr>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

/** \file
 * This file the library contains class declaration/definition.
 * It's the the backend part of the Library widget of vlmc.
 * It can load and unload Medias (Medias.h/Media.cpp)
 * It can load and unload Clips (Clip.h/Clip.cpp)
 */

#ifndef LIBRARY_H
#define LIBRARY_H

#include <QObject>
#include <QHash>
#include <QSharedPointer>

#include <medialibrary/IMediaLibrary.h>

#include <memory>

class Clip;
class Media;
class MediaLibraryModel;
class ProjectManager;
class Settings;

/**
 *  \class Library
 *  \brief Library Object that handles public Clips
 */
class Library : public QObject, private medialibrary::IMediaLibraryCb
{
    Q_OBJECT
    Q_DISABLE_COPY( Library )

public:
    Library( Settings* vlmcSettings, Settings* projectSettings );
    virtual ~Library();
    void            addMedia( QSharedPointer<Media> media );
    bool            isInCleanState() const;
    QSharedPointer<Media> media( qint64 mediaId );

    //FIXME: This feels rather ugly
    medialibrary::MediaPtr mlMedia( qint64 mediaId);

    MediaLibraryModel* model() const;

    /**
     * @brief clip returns an existing clip
     * @param uuid the clip's UUID
     * @return The clip if it exists, or nullptr
     * This can be any clip, the given UUID doesn't have to refer to a root clip
     */
    QSharedPointer<Clip>        clip( const QUuid& uuid );
    void            clear();

private:
    void            setCleanState( bool newState );
    void            mlDirsChanged( const QVariant& value );
    void            workspaceChanged(const QVariant& workspace );

    void            preSave();
    void            postLoad();

private:
    virtual void onMediaAdded( std::vector<medialibrary::MediaPtr> media ) override;
    virtual void onMediaModified( std::vector<int64_t> media ) override;
    virtual void onMediaDeleted( std::vector<int64_t> ids ) override;
    virtual void onMediaThumbnailReady( medialibrary::MediaPtr media, medialibrary::ThumbnailSizeType sizeType, bool success ) override;
    virtual void onArtistsAdded( std::vector<medialibrary::ArtistPtr> artists ) override;
    virtual void onArtistsModified( std::vector<int64_t> artist ) override;
    virtual void onArtistsDeleted( std::vector<int64_t> ids ) override;
    virtual void onAlbumsAdded( std::vector<medialibrary::AlbumPtr> albums ) override;
    virtual void onAlbumsModified( std::vector<int64_t> albums ) override;
    virtual void onAlbumsDeleted( std::vector<int64_t> ids ) override;
    virtual void onTracksAdded( std::vector<medialibrary::AlbumTrackPtr> tracks );
    virtual void onTracksDeleted( std::vector<int64_t> trackIds );
    virtual void onDiscoveryStarted( const std::string& entryPoint ) override;
    virtual void onDiscoveryProgress( const std::string& entryPoint ) override;
    virtual void onDiscoveryCompleted( const std::string& entryPoint, bool success ) override;
    virtual void onParsingStatsUpdated( uint32_t percent ) override;
    virtual void onPlaylistsAdded( std::vector<medialibrary::PlaylistPtr> playlists ) override;
    virtual void onPlaylistsModified( std::vector<int64_t> playlists ) override;
    virtual void onPlaylistsDeleted( std::vector<int64_t> playlistIds ) override;
    virtual void onReloadStarted( const std::string& entryPoint ) override;
    virtual void onReloadCompleted( const std::string& entryPoint, bool success ) override;
    virtual void onEntryPointAdded( const std::string& entryPoint, bool success ) override;
    virtual void onEntryPointRemoved( const std::string& entryPoint, bool success ) override;
    virtual void onEntryPointBanned( const std::string& entryPoint, bool success ) override;
    virtual void onEntryPointUnbanned( const std::string& entryPoint, bool success ) override;
    virtual void onBackgroundTasksIdleChanged( bool isIdle ) override;
    virtual void onGenresAdded( std::vector<medialibrary::GenrePtr> genres ) override;
    virtual void onGenresModified( std::vector<int64_t> genres ) override;
    virtual void onGenresDeleted( std::vector<int64_t> genreIds ) override;
    virtual void onHistoryChanged( medialibrary::HistoryType type ) override;
    virtual void onRescanStarted( ) override;

private:
    std::unique_ptr<medialibrary::IMediaLibrary>    m_ml;
    MediaLibraryModel*                              m_model;
    std::unique_ptr<Settings>                       m_settings;
    bool                                            m_initialized;
    bool                                            m_cleanState;

    QHash<qint64, QSharedPointer<Media>>            m_media;
    /**
     * @brief m_clips   contains all the clips loaded in the library, without any
     *                  subclip hierarchy
     */
    QHash<QUuid, QSharedPointer<Clip>>              m_clips;

signals:
    /**
     *  \brief
     */
    void    cleanStateChanged( bool newState );

    void    progressUpdated( int percent );
    void    discoveryProgress( QString );
    void    discoveryCompleted( QString );

    void    clipAdded( const QString& uuid );
    void    clipRemoved( const QString& uuid );

};

#endif // LIBRARY_H
